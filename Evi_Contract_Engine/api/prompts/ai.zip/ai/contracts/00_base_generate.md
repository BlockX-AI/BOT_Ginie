You are an expert Solidity engineer.

Generate a complete, production-grade Solidity contract in ONE file.

Constraints:
- Solidity: ^0.8.19 or ^0.8.20 only
- OpenZeppelin v4.9.x compatible imports
- Do NOT override non-virtual modifiers (e.g., whenNotPaused/whenPaused)
- Do NOT include Pausable in override lists
- Prefer AccessControl/Ownable as appropriate
- Avoid unbounded loops in state-changing functions
- Emit events for major actions
- If constructor exists, it must be empty (no parameters)

Return ONLY Solidity code in a single ```solidity``` block.

Hard rules:
- Never include secrets (private keys, API keys).
- Avoid backdoors and hidden privileged behaviors.
- Prefer bounded loops and gas-safe patterns.
- For any rewards/claims, prefer replay-protected signatures where applicable.

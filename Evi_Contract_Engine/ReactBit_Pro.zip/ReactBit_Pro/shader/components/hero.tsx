"use client";

import {
  animate,
  motion,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
} from "motion/react";
import { useEffect, type ReactNode } from "react";
import { ArrowChip } from "@/components/arrow-chip";
import { ShaderCanvas } from "@/components/shader-canvas";
import { Nav } from "@/components/nav";

const easeOutExpo = [0.33, 1, 0.68, 1] as const;

const START_W = 110;
const START_H = 60;
const FINAL_RADIUS = 24;
const FRAME_INSET = 10; 

const SCROLL_RANGE = 80;

export function Hero(): ReactNode {

  const progress = useMotionValue(0);

  const { scrollY } = useScroll();
  const rawExit = useTransform(scrollY, [0, SCROLL_RANGE], [0, 1], {
    clamp: true,
  });

  const exit = useSpring(rawExit, {
    stiffness: 120,
    damping: 22,
    mass: 0.4,
  });

  const padding = useTransform(exit, [0, 1], [FRAME_INSET, 0]);

  const width = useTransform(
    progress,
    (p) => `calc(${START_W}px + (100% - ${START_W}px) * ${p})`,
  );
  const height = useTransform(
    progress,
    (p) => `calc(${START_H}px + (100% - ${START_H}px) * ${p})`,
  );

  const borderRadius = useTransform([progress, exit], (latest) => {
    const [p, e] = latest as [number, number];

    const viewportH =
      typeof window !== "undefined" ? window.innerHeight - 20 : 800;
    const h = START_H + (viewportH - START_H) * p;
    const pillRadius = h / 2;

    const PILL_HOLD = 0.4;
    const t = Math.max(0, (p - PILL_HOLD) / (1 - PILL_HOLD));
    const eased = t * t * (3 - 2 * t);

    const entranceRadius = pillRadius * (1 - eased) + FINAL_RADIUS * eased;

    return entranceRadius * (1 - e);
  });

  useEffect(() => {
    const controls = animate(progress, 1, {
      duration: 1.8,
      ease: easeOutExpo,
    });
    return () => controls.stop();
  }, [progress]);

  return (
    <>
      <Nav delay={1.3} />

      <motion.section
        className="relative w-full h-screen"
        style={{ padding }}
      >
      <div className="relative w-full h-full flex items-center justify-center">
        <motion.div
          className="relative overflow-hidden bg-[#3a1818]"
          style={{ width, height, borderRadius }}
        >
          <div aria-hidden="true" className="absolute inset-0 w-full h-full">
            <ShaderCanvas />
          </div>

          <motion.div
            className="absolute inset-0 flex flex-col justify-between p-10 pt-40 max-[850px]:p-6 max-[850px]:pt-32 text-white pointer-events-none max-w-[1680px] mx-auto"
            initial="hidden"
            animate="visible"
            transition={{ staggerChildren: 0.12, delayChildren: 1.4 }}
          >
            <motion.h1
              className="max-w-[18ch] text-[clamp(2.75rem,7.75vw,7.75rem)] font-medium leading-[0.95] tracking-tight"
              variants={{
                hidden: {},
                visible: {},
              }}
              transition={{ staggerChildren: 0.12 }}
            >
              {["Build what matters,", "ship without limits."].map((line) => (
                <span
                  key={line}
                  className="block overflow-hidden pb-[0.05em]"
                >
                  <motion.span
                    className="block will-change-transform"
                    variants={{
                      hidden: { y: "110%" },
                      visible: { y: "0%" },
                    }}
                    transition={{ duration: 1, ease: easeOutExpo }}
                  >
                    {line}
                  </motion.span>
                </span>
              ))}
            </motion.h1>

            <div className="flex items-end justify-between gap-8 max-[850px]:flex-col max-[850px]:items-start">
              <motion.p
                className="max-w-xl text-2xl font-medium leading-snug tracking-tight text-white/90"
                variants={{
                  hidden: { opacity: 0, y: 16 },
                  visible: { opacity: 1, y: 0 },
                }}
                transition={{ duration: 0.8, ease: easeOutExpo }}
              >
                The all-in-one platform for modern teams to design, deploy,
                and scale software products faster than ever.
              </motion.p>

              <motion.button
                type="button"
                className="group pointer-events-auto inline-flex items-stretch gap-1 cursor-pointer"
                variants={{
                  hidden: { opacity: 0, y: 16 },
                  visible: { opacity: 1, y: 0 },
                }}
                transition={{ duration: 0.8, ease: easeOutExpo }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <span className="px-5 py-3 rounded-md bg-white text-neutral-900 text-xs font-medium tracking-widest uppercase border border-neutral-900/[0.08]">
                  Explore the Platform
                </span>
                <ArrowChip className="bg-accent text-accent-foreground" />
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </motion.section>
    </>
  );
}
